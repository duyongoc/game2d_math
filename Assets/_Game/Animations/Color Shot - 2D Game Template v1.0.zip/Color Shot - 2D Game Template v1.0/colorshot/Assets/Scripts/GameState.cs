public enum GameState
{
	MENU,
	PLAYING,
	PAUSED,
	GAMEOVER
}
