using UnityEngine;

public class CameraShake : MonoBehaviour
{
	private void Start()
	{
	}

	private void Update()
	{
	}
}
